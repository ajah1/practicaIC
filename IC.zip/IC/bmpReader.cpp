#include <iostream>
#include <fstream>
#include <stdint.h>
#include <string.h>
#include <sys/resource.h>

#include "EasyBMP.h"


using namespace std;



long double
tiempo(void){
 struct rusage usage;
 getrusage(RUSAGE_SELF,&usage);
 return( (long double) usage.ru_utime.tv_sec +
	 (long double) usage.ru_utime.tv_usec/1e6 
	 /* + (long double) usage.ru_stime.tv_sec +
         (long double) usage.ru_stime.tv_usec/1e6 */  
       );
}








RGBApixel bilinealInterpolation(RGBApixel pixela1, RGBApixel pixela2, RGBApixel pixelb1, RGBApixel pixelb2, float x, float y){

    RGBApixel tmp;


    
    int newRed = pixela1.Red * (1 - x) * ( 1 - y) +
            pixelb1.Red * (x) * (1 - y) +
            pixela2.Red * (1-x) * (y) +
            pixelb2.Red * x * y;

    int newGreen = pixela1.Green * (1 - y) * ( 1 - y) +
            pixelb1.Green * (x) * (1 - y) +
            pixela2.Green * (1-x) * (y) +
            pixelb2.Green * x * y;

    int newBlue = pixela1.Blue * (1 - y) * ( 1 - y) +
            pixelb1.Blue * (x) * (1 - y) +
            pixela2.Blue * (1-x) * (y) +
            pixelb2.Blue * x * y;


    int newAlpha = pixela1.Alpha * (1 - y) * ( 1 - y) +
            pixelb1.Alpha * (x) * (1 - y) +
            pixela2.Alpha * (1-x) * (y) +
            pixelb2.Alpha * x * y;
            
            
    tmp.Red = newRed;
    tmp.Green = newGreen;
    tmp.Blue = newBlue;
    tmp.Alpha = newAlpha;
    return tmp;

}


int main(int argc, char* argv[]){
    string filename;

    if (argc >= 2) {
        filename = argv[1];

    }else{

        cout << "Imagen de entrada: ";
        getline(cin, filename);


    }


    BMP OriginalImage;
    
    OriginalImage.ReadFromFile(filename.c_str());





    BMP FinalImage;

    FinalImage.SetSize(OriginalImage.TellWidth()*2,OriginalImage.TellHeight()*2 );
    FinalImage.SetBitDepth(OriginalImage.TellBitDepth());
    

        int width = OriginalImage.TellWidth()*2;
        int height = OriginalImage.TellHeight()*2;
        
    int n = 0;
    int m = 0;
    
    cout<< "comenzando" << endl;
    
    
    
        //obtenemos tiemoo
      long double ini = tiempo();



	for(int i=0; i< width ; i++){
            n = (i+1) /2;
            m = 0;
    		for(int j=0; j < height; j++){
                //cout << i<< " " << j << endl;

    			if(j%2 == 1){
                    if(i != 0 && j != 0 && i < width - 1  && j < height -1){
                            RGBApixel pixel1 = OriginalImage.GetPixel(i/2,j/2);
                            RGBApixel pixel2 = OriginalImage.GetPixel((i+1)/2,j/2);
                            RGBApixel pixel3 = OriginalImage.GetPixel(i/2,(j+1)/2);
                            RGBApixel pixel4 = OriginalImage.GetPixel((i+1)/2,(j+1)/2);

                            RGBApixel tmp = bilinealInterpolation( pixel1,pixel2,pixel3,pixel4,0.5,0.5 );  
                            
                            FinalImage.SetPixel(i,j,tmp); 

                    }
                }else if(i%2 == 1){
                    if(i != 0 && j != 0 && i < width - 1  && j < height -1){
                            RGBApixel pixel1 = OriginalImage.GetPixel(i/2,j/2);
                            RGBApixel pixel2 = OriginalImage.GetPixel((i+1)/2,j/2);
                            RGBApixel pixel3 = OriginalImage.GetPixel(i/2,(j+1)/2);
                            RGBApixel pixel4 = OriginalImage.GetPixel((i+1)/2,(j+1)/2);

                            RGBApixel tmp = bilinealInterpolation( pixel1,pixel2,pixel3,pixel4,0.5,0.5 );  
                            
                            FinalImage.SetPixel(i,j,tmp);                 
                    }
                }else{
                    //cout <<  "n: " << n<< " m: " << m << endl;
                    //cout <<  "i: " <<i<< " j:" << j << endl;
                    
                            RGBApixel pixel1 = OriginalImage.GetPixel(i/2,j/2);
                            RGBApixel pixel2 = OriginalImage.GetPixel((i+1)/2,j/2);
                            RGBApixel pixel3 = OriginalImage.GetPixel(i/2,(j+1)/2);
                            RGBApixel pixel4 = OriginalImage.GetPixel((i+1)/2,(j+1)/2);
                        RGBApixel tmp = bilinealInterpolation( pixel1,pixel2,pixel3,pixel4,0.5,0.5 );  
                        
                        FinalImage.SetPixel(i,j,OriginalImage.GetPixel(i/2,j/2));
                        
                        
                    //newPixels[i][j] = pixels[n][m];
                    //tmp = pixels[n][m];

                    m++;
                    
                   // cout << "asd" << endl;
                }




    		}

        }    
    
    
    
        //ordenamos



    //obtenesmo tiempo y restamos
      long double fin = tiempo();

     // cout <<"INI: " << ini << " FIN: " << fin << " "; 
      cout << "Tiempo Final: " << "  " << fin-ini <<  endl;
      
      
    
    FinalImage.WriteToFile("test.bmp");
    
    
	/*bmpHeader imageHeader;
    cout << filename << endl;

	ifstream image(filename.c_str(), std::ios::binary );

	cout << filename.c_str() << endl;
	if(image.is_open()){
		cout << "Fichero abierto" << endl;
		cout << "sizeof(imageHeader): " << sizeof(imageHeader) << endl;
    	image.read((char*)&imageHeader,sizeof(imageHeader));

    	cout << "Header: " << hex <<imageHeader.header << endl;
    	cout << "Width: " <<  dec << (int)imageHeader.width << endl;
    	cout << "Height: " <<  dec << (int)imageHeader.height << endl;

    	cout << "OFFSET: " << dec << (int)imageHeader.offset << endl; 
    	cout << "Bits per Pixel: " << dec << (int)imageHeader.bitsPerPixel << endl; 




    	//Pixel pixels[(int)imageHeader.width * (int)imageHeader.height];
        //Pixel pixels[(int)imageHeader.width ][(int)imageHeader.height];



// creamos la matriz !


    cout << "Alto: " << (int)imageHeader.height << endl;
    cout << "Ancho: " << (int)imageHeader.width << endl;

    Pixel **pixels = new Pixel* [(int)imageHeader.width];
    for (int i = 0; i < (int)imageHeader.width; i++){
        pixels[i] =  new(nothrow) Pixel[80];
        
        if( pixels[i] == nullptr){
            cout << "ERROR" << endl;
        }
        cout << i << "reserva" << endl;
    }



    


        cout << "pixels buffer: "<< sizeof(Pixel)*80*80 <<  endl;
        
        image.seekg((int)imageHeader.offset , ios_base::beg	 );

    	image.read((char*)&pixels,sizeof(Pixel) *10*10  );

      	image.close();


        cout << "El multiplo mas cercano de 6 es: " << isMul4(6) << endl;


    	//Reservamos matriz del doble de tamaño 
    	//Pixel newPixels[(int)imageHeader.width*2 * (int)imageHeader.height* 2];
       // Pixel newPixels[(int)imageHeader.width*2] [(int)imageHeader.height* 2];


    Pixel **newPixels = new Pixel* [(int)imageHeader.width*2];
    for (int i = 0; i < (int)imageHeader.width*2; i++){
        newPixels[i] = new Pixel[(int)imageHeader.height*2];
        //cout << "reserva" << endl;
    }
    
    
    
  		//Lets create a big image



    Pixel negro;
    	negro.g=0;
    	negro.r=0;
    	negro.b=0;

  	Pixel blanco;
    	blanco.g=0xff;
    	blanco.r=0xff;
    	blanco.b=0xff;

  	Pixel red;
    	red.g=0x00;
    	red.r=0xff;
    	red.b=0x00;




       // Pixel tmpPix = bilinealInterpolation(red,red,blanco,blanco,0.5,0.5);



       // cout << "r: " << (int)tmpPix.r << "g: " << (int)tmpPix.g << "b: " << (int)tmpPix.b << endl;
       
       
       cout << "test...." << endl;
       
       pixels[0][0] = negro;
        cout << "test...." << endl;

        for(int i=0; i< (int)imageHeader.width ; i++){
            for(int j=0; j< (int)imageHeader.height ; j++){
                cout << i << j << endl;
                    pixels[i][j] = negro;
            }
        }
        cout << "ha pasado el test" <<  endl;
        
 		cout << "Relleno de negro" << endl;

        for(int i=0; i< (int)imageHeader.width*2  ; i++){
                for(int j=0; j< (int)imageHeader.height *2 ; j++){
                    newPixels[i][j] = negro;
            }
        }

        int padding = isMul4(imageHeader.width*2*3) - imageHeader.width*2*3;

        cout << "El padding es: "<< padding << endl;
        int n=0;
        int m=0;
        Pixel tmp;
        tmp = red;
    	for(int i=0; i< (int)imageHeader.width*2 ; i++){
            n = (i+1) /2;
            m = 0;
    		for(int j=0; j < (int)imageHeader.height*2; j++){
                //cout << i<< " " << j << endl;

    			if(j%2 == 1){

                    //newPixels[i][j] = negro;



                if(i != 0 && j != 0 && i < (imageHeader.width-1) * 2  && j < (imageHeader.height-1) * 2){
                   
                  
                          newPixels[i][j] = bilinealInterpolation( pixels[i/2][j/2],pixels[i/2+1][j/2],pixels[i/2][j/2+1],pixels[i/2+1][j/2+1],0.5,0.5 );  

                }


                }else if(i%2 == 1){

                    //newPixels[i] [j] = blanco;




                if(i != 0 && j != 0 && i < (imageHeader.width-1)*2  && j < (imageHeader.height-1)*2 ){
                
                          newPixels[i][j] = bilinealInterpolation( pixels[i/2][j/2],pixels[i/2-1][j/2],pixels[i/2][j/2-1],pixels[i/2-1][j/2-1],0.5,0.5 );  
                 }

                }else{
                    cout <<  "n: " << n<< " m: " << m << endl;
                    cout <<  "i: " <<i<< " j:" << j << endl;
                    
                    newPixels[i][j] = pixels[n][m];
                    tmp = pixels[n][m];

                    m++;
                    
                    cout << "asd" << endl;
                }




    		}

        }
//
        imageHeader.width *=2;
		imageHeader.height *=2;
		imageHeader.sizeF *=2;

    	cout << "Generemos nuevo archivo ..." << endl;

  		ofstream outputF("test.bmp",std::ios::binary);




  		 outputF.write ((char *)&imageHeader,sizeof(imageHeader));
  		 outputF.write ((char *)newPixels,sizeof(newPixels));

  		 outputF.close();

	}else{
		cout << "Can't not open the file" << endl;

	}
*/
	return 0;
}